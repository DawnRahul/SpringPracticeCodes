package com.rahul.practice2;

public interface SortingAlgorithm {

	abstract int[] sort(int[] numbers);
}
