package com.rahul.practice2;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practice2Application {

	public static void main(String[] args) {
		int[] numbers = {2,4,3,5};
		int numberToSearch = 5;
		
		ApplicationContext applicationContext = SpringApplication.run(com.rahul.practice2.Practice2Application.class, args);
		
		BinarySearchImp binarySearchImp = applicationContext.getBean(BinarySearchImp.class);
		
		int searchResult = binarySearchImp.binarySearch(numbers, numberToSearch);
		
		//pass the SortingAlgorithm type
//		BinarySearchImp bs = new BinarySearchImp(new QuickSortAlgorithm());
//		
//		int searchResult = bs.binarySearch(numbers, numberToSearch);
//		
		System.out.println("Searched number : " + searchResult);
		
		
//		SpringApplication.run(Practice1Application.class, args);
	}

}
