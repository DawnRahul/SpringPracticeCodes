package com.rahul.practice2;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class QuickSortAlgorithm implements SortingAlgorithm {

	public int[] sort(int[] numbers) {
		// sorting
		
		System.out.println("used quick-sorting!");
		
		return numbers;
	}
}
