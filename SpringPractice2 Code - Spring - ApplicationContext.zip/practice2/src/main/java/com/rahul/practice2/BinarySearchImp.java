package com.rahul.practice2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BinarySearchImp {
	@Autowired
	private SortingAlgorithm sortAlgorithm;
	
	//by using constructor
	
//	public BinarySearchImp(SortingAlgorithm sortAlgorithm) {
//		super();
//		this.sortAlgorithm = sortAlgorithm;
//	}
	
	//by using setter
	public void setSortAlgorithm(SortingAlgorithm sortAlgorithm) {
		this.sortAlgorithm = sortAlgorithm;
	}
	
	public int binarySearch(int [] numbers, int num) {
		
		//sorting
		int[] sortedNumbers = sortAlgorithm.sort(numbers);
		
		//searching number in Array 
		
		
		//returning
		return 7;
	}
}
