package com.rahul.practice2;

import org.springframework.stereotype.Component;

@Component
public class BubbleSortAlgorithm implements SortingAlgorithm{
	
	public int[] sort(int[] numbers) {
			// sorting
		System.out.println("used bubble-sorting!");
		return numbers;
	}

}


