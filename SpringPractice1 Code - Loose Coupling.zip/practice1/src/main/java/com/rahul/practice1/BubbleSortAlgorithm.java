package com.rahul.practice1;

public class BubbleSortAlgorithm implements SortingAlgorithm{
	
	public int[] sort(int[] numbers) {
			// sorting
		System.out.println("used bubble-sorting!");
		return numbers;
	}

}


