package com.rahul.practice1;

public interface SortingAlgorithm {

	abstract int[] sort(int[] numbers);
}
