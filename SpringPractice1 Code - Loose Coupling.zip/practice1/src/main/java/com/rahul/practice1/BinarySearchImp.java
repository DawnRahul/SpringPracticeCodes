package com.rahul.practice1;

public class BinarySearchImp {
	
	private SortingAlgorithm sortAlgorithm;
	
	public BinarySearchImp(SortingAlgorithm sortAlgorithm) {
		super();
		this.sortAlgorithm = sortAlgorithm;
	}
	
	
	public int binarySearch(int [] numbers, int num) {
		
		//sorting
		int[] sortedNumbers = sortAlgorithm.sort(numbers);
		
		//searching number in Array 
		
		
		//returning
		return 7;
	}
}
