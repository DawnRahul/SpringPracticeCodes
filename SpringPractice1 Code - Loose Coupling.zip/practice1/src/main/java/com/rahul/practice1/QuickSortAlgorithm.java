package com.rahul.practice1;

public class QuickSortAlgorithm implements SortingAlgorithm {

	public int[] sort(int[] numbers) {
		// sorting
		
		System.out.println("used quick-sorting!");
		
		return numbers;
	}
}
